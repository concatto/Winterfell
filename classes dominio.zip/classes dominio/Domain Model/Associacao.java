

/**
 * @author 5928036
 * @version 1.0
 * @created 20-mar-2017 22:07:36
 */
public class Associacao {

	private Pessoa seguido;
	private Pessoa seguidor;

	public Associacao(){

	}

	public void finalize() throws Throwable {

	}

}