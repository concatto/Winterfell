

/**
 * @author 5928036
 * @version 1.0
 * @created 20-mar-2017 22:07:37
 */
public class Reacao {

	private TipoReacao tipo;

	public Reacao(){

	}

	public void finalize() throws Throwable {

	}

}